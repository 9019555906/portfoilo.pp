## Packages
framer-motion | Complex animations and scroll reveals
react-scroll | Smooth scrolling for navigation links

## Notes
Using framer-motion for entry animations and scroll-triggered reveals.
Dark mode is the default theme.
Images handled via Unsplash placeholder URLs where dynamic content isn't available.
