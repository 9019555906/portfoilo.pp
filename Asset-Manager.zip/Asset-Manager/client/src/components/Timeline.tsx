import { motion } from "framer-motion";
import { useEducation, useCertifications } from "@/hooks/use-portfolio";
import { GraduationCap, Award, Calendar } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export function Timeline() {
  const { data: education, isLoading: eduLoading } = useEducation();
  const { data: certifications, isLoading: certLoading } = useCertifications();

  const isLoading = eduLoading || certLoading;

  return (
    <section id="education" className="section-padding">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Education Column */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="mb-10 flex items-center gap-4"
            >
              <div className="p-3 bg-primary/10 rounded-xl text-primary">
                <GraduationCap size={32} />
              </div>
              <h2 className="text-3xl font-bold">Education</h2>
            </motion.div>

            {isLoading ? (
              <div className="space-y-6">
                <Skeleton className="h-32 w-full rounded-xl" />
                <Skeleton className="h-32 w-full rounded-xl" />
              </div>
            ) : (
              <div className="space-y-8 relative border-l-2 border-border ml-4 pl-8 py-2">
                {education?.map((edu, idx) => (
                  <motion.div
                    key={edu.id}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="relative"
                  >
                    <span className="absolute -left-[41px] top-1 w-5 h-5 rounded-full bg-primary border-4 border-background" />
                    <div className="glass-card p-6 rounded-xl hover:border-primary/50 transition-colors">
                      <span className="inline-flex items-center gap-2 text-sm text-primary font-medium mb-2 bg-primary/10 px-3 py-1 rounded-full">
                        <Calendar size={14} /> {edu.year}
                      </span>
                      <h3 className="text-xl font-bold mt-2">{edu.degree}</h3>
                      <p className="text-muted-foreground mt-1 text-lg">{edu.institution}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>

          {/* Certifications Column */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="mb-10 flex items-center gap-4"
            >
              <div className="p-3 bg-blue-500/10 rounded-xl text-blue-500">
                <Award size={32} />
              </div>
              <h2 className="text-3xl font-bold">Certifications</h2>
            </motion.div>

            {isLoading ? (
              <div className="space-y-6">
                <Skeleton className="h-24 w-full rounded-xl" />
                <Skeleton className="h-24 w-full rounded-xl" />
              </div>
            ) : (
              <div className="grid gap-4">
                {certifications?.map((cert, idx) => (
                  <motion.div
                    key={cert.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-card p-5 rounded-xl border border-border hover:border-blue-500/50 transition-colors flex items-start gap-4 group"
                  >
                    <div className="mt-1 p-2 bg-secondary rounded-lg group-hover:bg-blue-500/20 group-hover:text-blue-500 transition-colors">
                      <Award size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{cert.name}</h3>
                      <p className="text-muted-foreground">{cert.issuer}</p>
                      {cert.year && <p className="text-xs text-muted-foreground/60 mt-1">{cert.year}</p>}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
