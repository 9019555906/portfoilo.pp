import { motion } from "framer-motion";
import { ArrowDown, Mail, Github, Linkedin, Smartphone } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Hero() {
  const scrollTo = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="min-h-screen flex items-center relative overflow-hidden pt-20">
      {/* Background decoration */}
      <div className="absolute top-20 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] -z-10" />
      <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[100px] -z-10" />

      <div className="container mx-auto px-4 md:px-6 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="order-2 lg:order-1"
        >
          <div className="inline-block px-3 py-1 mb-4 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-semibold">
            Available for opportunities
          </div>
          <h1 className="text-5xl md:text-7xl font-bold font-display leading-tight mb-6">
            Hi, I'm <br />
            <span className="text-gradient">Preethu S M</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-lg leading-relaxed">
            Engineering Student & Aspiring Software Engineer.
            Passionate about building efficient systems and crafting beautiful web experiences.
          </p>

          <div className="flex flex-wrap gap-4 mb-10">
            <Button 
              size="lg" 
              className="rounded-full text-base px-8 h-12 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30"
              onClick={() => scrollTo("#projects")}
            >
              View My Work
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="rounded-full text-base px-8 h-12 border-2 hover:bg-secondary/50"
              onClick={() => scrollTo("#contact")}
            >
              Contact Me
            </Button>
          </div>

          <div className="flex items-center gap-6 text-muted-foreground">
            <a href="https://www.linkedin.com/in/preethu-sm-879900363" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors hover:scale-110 transform duration-200">
              <Linkedin size={24} />
            </a>
            <a href="mailto:preethusm41@gmail.com" className="hover:text-primary transition-colors hover:scale-110 transform duration-200">
              <Mail size={24} />
            </a>
            <div className="flex items-center gap-2 text-sm">
              <Smartphone size={18} />
              <span>+91 9019555906</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="order-1 lg:order-2 flex justify-center relative"
        >
          <div className="relative w-72 h-72 md:w-96 md:h-96">
            <div className="absolute inset-0 border-2 border-primary/30 rounded-full animate-[spin_10s_linear_infinite]" />
            <div className="absolute inset-4 border-2 border-dashed border-blue-500/30 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
            <div className="absolute inset-0 rounded-full overflow-hidden bg-gradient-to-br from-primary/20 to-blue-500/20 backdrop-blur-sm flex items-center justify-center border border-white/10">
              {/* Using a placeholder avatar since no specific image was provided, but structured for replacement */}
              {/* Unsplash image of a developer setup or abstract tech */}
              <img 
                src="https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&h=800&fit=crop" 
                alt="Profile Abstract" 
                className="w-full h-full object-cover opacity-80 mix-blend-overlay" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-60" />
              <div className="absolute bottom-10 text-center w-full px-4">
                 <p className="text-white font-bold text-lg drop-shadow-md">Mandya, Karnataka, India</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce hidden md:block">
        <button onClick={() => scrollTo("#about")} className="text-muted-foreground hover:text-primary transition-colors">
          <ArrowDown size={24} />
        </button>
      </div>
    </section>
  );
}
