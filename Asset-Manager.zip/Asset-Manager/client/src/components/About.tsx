import { motion } from "framer-motion";
import { User, Code, Globe, Cpu } from "lucide-react";

export function About() {
  return (
    <section id="about" className="section-padding bg-secondary/20 relative">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About Me</h2>
            <div className="w-20 h-1 bg-primary mx-auto rounded-full" />
          </div>

          <div className="glass-card rounded-2xl p-8 md:p-12 mb-12">
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed text-center italic">
              "To secure a challenging position as a fresher where I can utilize my technical skills in programming, web development, and electronics projects, while gaining practical experience and contributing to the growth of the organization."
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl bg-card border border-border/50 hover:border-primary/50 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-4 group-hover:bg-primary group-hover:text-white transition-all">
                <Code size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Development</h3>
              <p className="text-muted-foreground">Passionate about software engineering and building robust web applications.</p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border/50 hover:border-primary/50 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500 mb-4 group-hover:bg-blue-500 group-hover:text-white transition-all">
                <Cpu size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Electronics</h3>
              <p className="text-muted-foreground">Background in electronics engineering with a keen interest in embedded systems.</p>
            </div>

            <div className="p-6 rounded-xl bg-card border border-border/50 hover:border-primary/50 transition-colors group">
              <div className="w-12 h-12 rounded-lg bg-pink-500/10 flex items-center justify-center text-pink-500 mb-4 group-hover:bg-pink-500 group-hover:text-white transition-all">
                <Globe size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">Languages</h3>
              <p className="text-muted-foreground">Fluent in Kannada and English, enabling effective communication.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
