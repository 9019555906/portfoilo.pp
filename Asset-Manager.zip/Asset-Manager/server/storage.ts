import { db } from "./db";
import { 
  skills, projects, education, certifications, messages,
  type Skill, type Project, type Education, type Certification, type Message, type InsertMessage
} from "@shared/schema";

export interface IStorage {
  getSkills(): Promise<Skill[]>;
  getProjects(): Promise<Project[]>;
  getEducation(): Promise<Education[]>;
  getCertifications(): Promise<Certification[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  seedData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getSkills(): Promise<Skill[]> {
    return await db.select().from(skills);
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async getEducation(): Promise<Education[]> {
    return await db.select().from(education);
  }

  async getCertifications(): Promise<Certification[]> {
    return await db.select().from(certifications);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async seedData(): Promise<void> {
    const skillsCount = await db.select().from(skills);
    if (skillsCount.length === 0) {
      await db.insert(skills).values([
        { name: "Python", category: "Language", proficiency: 60 },
        { name: "C", category: "Language", proficiency: 60 },
        { name: "HTML", category: "Web", proficiency: 85 },
        { name: "CSS", category: "Web", proficiency: 80 },
        { name: "Microcontroller Basics", category: "Electronics", proficiency: 70 },
        { name: "Electronics Basics", category: "Electronics", proficiency: 75 },
      ]);
    }

    const projectsCount = await db.select().from(projects);
    if (projectsCount.length === 0) {
      await db.insert(projects).values([
        { 
          title: "AI Image Classification", 
          description: "A Bootcamp project focusing on classifying images using Artificial Intelligence techniques.",
          tags: ["Python", "AI", "Machine Learning"] 
        },
        { 
          title: "Heartbeat Monitoring System", 
          description: "A microcontroller-based project using Arduino and Pulse Sensor to monitor heartbeat in real-time.",
          tags: ["Arduino", "C", "Electronics", "IoT"] 
        },
      ]);
    }

    const educationCount = await db.select().from(education);
    if (educationCount.length === 0) {
      await db.insert(education).values([
        { degree: "B.E (Pursuing)", institution: "University of Mysore", year: "Present" },
        { degree: "12th PUC", institution: "Dept. of Pre-University Education, Karnataka", year: "2023" },
        { degree: "10th SSLC", institution: "Karnataka Secondary Education Board", year: "2021" },
      ]);
    }

    const certsCount = await db.select().from(certifications);
    if (certsCount.length === 0) {
      await db.insert(certifications).values([
        { name: "GitHub Workshop Certificate", issuer: "GitHub", year: "2023" }, // Estimated year
        { name: "Prompt Image Generation Event Certificate", issuer: "PES College, Mandya", year: "2023" }, // Estimated year
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
